# backend/main.py
import os
import re
from gtts import gTTS

# --- Sanitize Input ---
def sanitize_input(text: str):
    """Check if input text is valid for processing."""
    if not text or not text.strip():
        return {"valid": False, "message": "Please enter or upload some text."}
    if len(text.strip()) < 5:
        return {"valid": False, "message": "Text is too short. Please add more content."}
    return {"valid": True, "text": text.strip()}

# --- Transform Text Tone ---
def transform_text_tone(text: str, tone: str):
    """Apply a simple transformation to reflect chosen tone."""
    if tone == "Suspenseful":
        return f"🔦 [Suspenseful Narration Begins] {text}"
    elif tone == "Inspiring":
        return f"💡 [Inspiring Narration Begins] {text}"
    elif tone == "Motivational":
        return f"🔥 [Motivational Narration Begins] {text}"
    return text  # Neutral (no change)

# --- Synthesize Audio ---
def synthesize_audio(text: str, voice: str):
    """Convert text to speech and save as MP3."""
    # gTTS doesn’t support custom voices, but we can switch lang/accents.
    # To simulate different narrators, we just save with different filenames.
    filename = f"echoverse_{voice.lower()}.mp3"
    
    tts = gTTS(text=text, lang="en")
    tts.save(filename)
    
    return filename

# --- Logger ---
def log_event(message: str, level="INFO"):
    """Log messages to console or file."""
    print(f"[{level}] {message}")
