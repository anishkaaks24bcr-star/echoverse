# app.py
import streamlit as st
import os
import streamlit.components.v1 as components
from backend import main

# --- Page Setup ---
st.set_page_config(page_title="EchoVerse 🎧", layout="wide")

# --- Custom CSS for Dynamic UI ---
st.markdown("""
<style>
body {
    background: linear-gradient(135deg,#ff9a9e 0%, #fad0c4 25%, #fad0c4 50%, #fbc2eb 75%, #a18cd1 100%);
    background-attachment: fixed;
    color: #1a1a1a;
    font-family: "Segoe UI", sans-serif;
}
.stButton>button {
    background: linear-gradient(90deg,#667eea,#764ba2);
    color: white;
    border-radius: 12px;
    font-size: 18px;
    padding: 0.6rem 1rem;
    transition: all 0.3s ease-in-out;
}
.stButton>button:hover {
    background: linear-gradient(90deg,#ff6a00,#ee0979);
    transform: scale(1.05);
}
.stTextArea textarea, .stSelectbox div, .stRadio div {
    border-radius: 10px;
}
.block-container {
    padding-top: 2rem;
}
</style>
""", unsafe_allow_html=True)

# --- Title & Subtitle ---
st.title("🎧 EchoVerse – AI Audiobook Creator")
st.markdown("**Transform text into expressive, professional narration.** Upload a file or type your own content!")

# --- File Upload + Editable Text Area ---
uploaded_file = st.file_uploader("📂 Upload a .txt file", type=["txt"])

# Start with typed text
text_input = st.session_state.get("text_input", "")

if uploaded_file:
    file_text = uploaded_file.read().decode("utf-8")
    if not text_input:  # load only if textarea is empty
        text_input = file_text

# Editable text area (either file content or manual input)
typed_text = st.text_area("📖 Your Text (Editable)", value=text_input, height=250)
st.session_state["text_input"] = typed_text  # save state

# --- Voice & Tone Controls ---
col1, col2 = st.columns(2)
with col1:
    tone = st.selectbox("🎭 Narrative Tone", ["Neutral", "Suspenseful", "Inspiring", "Motivational"])
with col2:
    voice = st.radio("🗣 Narrator’s Voice", ["Lisa", "Michael", "Allison"])

# --- Waveform Player Function ---
def waveform_player(audio_file: str):
    """Embed Wavesurfer.js waveform audio player in Streamlit."""
    import base64

    with open(audio_file, "rb") as f:
        audio_bytes = f.read()

    audio_base64 = base64.b64encode(audio_bytes).decode("utf-8")
    audio_src = f"data:audio/mp3;base64,{audio_base64}"

    html_code = f"""
    <div id="waveform"></div>
    <div style="margin-top:10px;">
        <button id="playBtn" style="
            background: linear-gradient(90deg,#667eea,#764ba2);
            color:white;
            border:none;
            padding:10px 18px;
            border-radius:10px;
            font-size:16px;
            cursor:pointer;">▶️ Play / Pause</button>
    </div>
    <script src="https://unpkg.com/wavesurfer.js"></script>
    <script>
        var wavesurfer = WaveSurfer.create({{
            container: '#waveform',
            waveColor: '#a18cd1',
            progressColor: '#764ba2',
            cursorColor: '#333',
            height: 100,
            responsive: true
        }});
        wavesurfer.load("{audio_src}");
        document.getElementById("playBtn").onclick = () => wavesurfer.playPause();
    </script>
    """
    components.html(html_code, height=220)

# --- Generate Audio Button ---
if st.button("🔊 Generate & Preview Audio", use_container_width=True):
    if not typed_text.strip():
        st.error("⚠️ Please upload a .txt file or enter some text.")
        st.stop()

    inp = main.sanitize_input(typed_text.strip())
    if not inp["valid"]:
        st.error(inp["message"])
    else:
        with st.spinner("✨ Crafting narration & generating audio..."):
            try:
                rewritten = main.transform_text_tone(inp["text"], tone)
                audio_file = main.synthesize_audio(rewritten, voice)

                st.success("✅ Your narration is ready!")

                # --- Waveform Player ---
                waveform_player(audio_file)

                # --- Download Button ---
                with open(audio_file, "rb") as f:
                    st.download_button(
                        "⬇️ Download MP3",
                        f,
                        file_name="EchoVerse_Narration.mp3",
                        mime="audio/mp3"
                    )

            except Exception as e:
                main.log_event(str(e), level="ERROR")
                st.error("❌ Generation failed. Try again or use different options.")

st.caption("✨ Built with 💜 by EchoVerse – Bringing your stories to life.")